package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LoginView extends JFrame {

    private class LoginClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {


            try {
                Class.forName("org.postgresql.Driver");
                Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/oop", "postgres", "lambor345");
                Statement st = conn.createStatement();
                String query = "SELECT \"User_name\", \"password\" FROM \"Users\"";
                ResultSet rs = st.executeQuery(query);
                rs = st.executeQuery(query);
                while (rs.next()) {
                    String Uname = new String(rs.getString(1));
                    String pass = new String(rs.getString(2));
                    String name = user.getText();
                    if (Uname.equals(name) && pass.equals(parola.getText())) {

                        PageView page = new PageView();
                        ProductView productView = new ProductView();
                        page.setProductView(productView);
                        page.setVisible(true);
                    }
                }
                st.close();
                conn.close();
            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        }
    }


                /*try {
                    Class.forName("org.postgresql.Driver");
                    Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/oop", "postgres", "lambor345");
                    Statement st = conn.createStatement();
                    st.executeQuery("SELECT User_name FROM \"Users\"");
                    PageView page = new PageView();
                    ProductView productView = new ProductView();
                    page.setProductView(productView);
                    page.setVisible(true);
                    st.close();
                    conn.close();
                } catch (ClassNotFoundException | SQLException ex) {
                    ex.printStackTrace();
                    System.out.println("lol");
                    addError();
                }

                String queryString = "SELECT SName, SPwd FROM staff";
                ResultSet results = Statement.executeQuery(queryString);

                while (results.next()) {
                    String staffname = results.getString("snameeee");
                    String password =  results.getString("SPwd");

                    if ((f.equals(staffname)) && (s.equals(password))) {

                        JOptionPane.showMessageDialog(null, "Username and Password exist");
                    }else {

                        //JOptionPane.showMessageDialog(null, "Please Check Username and Password ");
                    }
                    results.close();
                } catch (SQLException sql) {

                    out.println(sql);
                }*/
               /* if(user.getText().equals("razvan") && password.equals("123")){
                    SignUp signup = new SignUp();
                    signup.setVisible(true);
                }
                else {
                    addError();
                }*/


            private class SignupClickListener implements ActionListener {

                @Override
                public void actionPerformed(ActionEvent e) {
                    SignUp signup = new SignUp();
                    signup.setVisible(true);
                }
            }

            private void addGreetingMessage () {
                helloMsg.setBounds(120, 50, 300, 40);
                helloMsg.setFont(new Font("Serif", Font.PLAIN, 32));
                add(helloMsg);
            }

            private static final JLabel helloMsg = new JLabel("Hello group 30421");
            private static final JLabel instr = new JLabel("Please input your credentials below: ");
            private static final JTextField user = new JTextField("Username");
            private static final JPasswordField parola = new JPasswordField("Password");
            private static final JLabel userMsg = new JLabel("Username:");
            private static final JLabel passMsg = new JLabel("Password");
            private static final JButton button = new JButton("Log in");
            private static final JLabel error = new JLabel("Incorrect");
            private static final JLabel notlogged = new JLabel("Don't have an account? Sign up!");
            private static final JButton signup = new JButton("Sign Up");

    public LoginView() {
                setTitle("Online Book Shop");

                setSize(400, 400);

                setLayout(null);

                setLocationRelativeTo(null);

                setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                setBackground(Color.blue);

                addInput();
                button.addActionListener(new LoginClickListener());
                signup.addActionListener(new SignupClickListener());
            }

            private void addError () {
                error.setBounds(120, 50, 300, 40);
                error.setFont(new Font("Serif", Font.PLAIN, 32));
                add(error);
            }

            private void addInput () {

                instr.setBounds(100, 60, 300, 20);
                add(instr);

                userMsg.setBounds(80, 100, 300, 20);
                user.setBounds(80, 130, 300, 25);
                add(userMsg);
                add(user);

                passMsg.setBounds(80, 160, 300, 20);
                parola.setBounds(80, 190, 300, 25);
                add(passMsg);
                add(parola);

                button.setBounds(160, 230, 80, 30);
                add(button);

                notlogged.setBounds(100, 270, 300, 30);
                add(notlogged);

                signup.setBounds(160, 310, 80, 30);
                add(signup);
            }


        }


